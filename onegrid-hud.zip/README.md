# OneGrid HUD Resource Pack

Pack de glyphes pour le HUD BossBar OneGrid.

Le plugin utilise la police `onegrid:hud` pour afficher les icones, les fonds de pastilles et les espacements negatifs.
Le pack declare aussi ces memes glyphes dans `minecraft:default`, car certains rendus de BossBar peuvent aplatir l'information de police.

Archive generee attendue : `server-resource-packs/onegrid-hud.zip`.

Si le serveur a deja un resource pack avec une font custom, ne remplace pas ce pack par `onegrid-hud.zip`.
Fusionne plutot ces fichiers dans le pack existant :

- `assets/onegrid/font/hud.json`
- `assets/minecraft/font/default.json`
- `assets/onegrid/textures/font/*.png`
- `assets/minecraft/textures/gui/sprites/boss_bar/*.png`

Les sprites `boss_bar` sont transparents pour masquer la barre vanilla tout en
gardant le texte BossBar du HUD.

Puis configure le plugin :

```yaml
ui:
  hud:
    resource-pack-glyphs: true
    text-font: "minecraft:default"
```

Garde `minecraft:default` si votre pack remplace deja `assets/minecraft/font/default.json`.
Utilise une autre cle, par exemple `onegrid:ui`, si votre font custom est declaree dans `assets/onegrid/font/ui.json`.
